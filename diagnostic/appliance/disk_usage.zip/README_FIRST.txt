This "disk_usage" tool allows you to analyze the /iswga/ls.txt found in the support file generated from the ISAM appliance 
(which shows all the files on the partition which was active when the support file was generated). 

The tool is useful to allow you to identify 
- which files are using the most space
- the amount of disk space used up my all the files in a directory
- how many files are in a directory


>>> NOTE:<<<
The disk_usage.sh calls the disk_usage.awk script.    
The location of the awk script MUST be updated in the following section of the sh file

###  This variable MUST be adjusted for you ###
# Example:
# awkfile=/tmp/disk_usage.awk
awkfile="<PATH_TO_AWK_FILE>/disk_usage.awk"


Usage:
disk_usage.sh ls.txt [directory]

The tool will report the data for all the directories unless you want to see only a specific one, 
specified by the [directory] parameter.



