#!/usr/bin/bash
# Please report any bugs or suggestions to
# Daniel Comeau  dcomeau@ca.ibm.com
# 03/03/2020 - Version 1.0

# Ensure awkfile points to the correct location of the awk script
awkfile="/tools/jct.awk"

echo ""

if [ -z $1 ]; then
  printf "%-30s%12s\t%s\n" "Junction" "Type" "Filename"
  printf "%-30s%12s\t%s\n" "========" "====" "========"
  for file in *.xml; do awk -f $awkfile ./$file; done|sort
  echo ""
  echo "Type:"
  printf "%s\n" "   - Regular Traditional Junction" " T - Transparent Path Junction" " V - Virtualhost Junction"

elif [[ $1 = "-h" || $1 = "-?" ]]; then
  echo "Usage: ./jct/sh [search string]"
  exit

else
  grep -p -i $1 *.xml
fi
